import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../d5ee9a47-8484-4824-a609-996298830b51/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const caribbeanShoreWithRocksPatch = new Entity('caribbeanShoreWithRocksPatch')
engine.addEntity(caribbeanShoreWithRocksPatch)
caribbeanShoreWithRocksPatch.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(25, 0, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanShoreWithRocksPatch.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("fd9eb4ee-2caa-4fc5-8bd3-bc34288b515e/WaterPatchCurve_01/WaterPatchCurve_01.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
caribbeanShoreWithRocksPatch.addComponentOrReplace(gltfShape)

const archwayOfHonesty = new Entity('archwayOfHonesty')
engine.addEntity(archwayOfHonesty)
archwayOfHonesty.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(14, 0, 25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
archwayOfHonesty.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("8f63046f-c2c5-4750-800a-921d57d82163/ChineseGate_02/ChineseGate_02.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
archwayOfHonesty.addComponentOrReplace(gltfShape2)

const imperialGuardianLionStatue = new Entity('imperialGuardianLionStatue')
engine.addEntity(imperialGuardianLionStatue)
imperialGuardianLionStatue.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(18.5, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imperialGuardianLionStatue.addComponentOrReplace(transform4)
const gltfShape3 = new GLTFShape("aaf9ba7e-b8e3-4f5f-bc47-67a20d516526/ChineseStatueLion_01/ChineseStatueLion_01.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
imperialGuardianLionStatue.addComponentOrReplace(gltfShape3)

const instagramButtonLink = new Entity('instagramButtonLink')
engine.addEntity(instagramButtonLink)
instagramButtonLink.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(25, 0, 20.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
instagramButtonLink.addComponentOrReplace(transform5)

const instagramButtonLink2 = new Entity('instagramButtonLink2')
engine.addEntity(instagramButtonLink2)
instagramButtonLink2.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(48, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
instagramButtonLink2.addComponentOrReplace(transform6)

const lightYellowPineTree = new Entity('lightYellowPineTree')
engine.addEntity(lightYellowPineTree)
lightYellowPineTree.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(46, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lightYellowPineTree.addComponentOrReplace(transform7)
const gltfShape4 = new GLTFShape("02606ec8-602e-4a5f-9485-06a1594be6e9/TreePine_02/TreePine_02.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
lightYellowPineTree.addComponentOrReplace(gltfShape4)

const lightGreenSycamoreTree = new Entity('lightGreenSycamoreTree')
engine.addEntity(lightGreenSycamoreTree)
lightGreenSycamoreTree.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lightGreenSycamoreTree.addComponentOrReplace(transform8)
const gltfShape5 = new GLTFShape("eb584cdc-2d37-45a1-a464-45007058b3d5/TreeSycamore_01/TreeSycamore_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
lightGreenSycamoreTree.addComponentOrReplace(gltfShape5)

const lightGreenSycamoreTree2 = new Entity('lightGreenSycamoreTree2')
engine.addEntity(lightGreenSycamoreTree2)
lightGreenSycamoreTree2.setParent(_scene)
lightGreenSycamoreTree2.addComponentOrReplace(gltfShape5)
const transform9 = new Transform({
  position: new Vector3(40.5, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lightGreenSycamoreTree2.addComponentOrReplace(transform9)

const lightGreenSycamoreTree3 = new Entity('lightGreenSycamoreTree3')
engine.addEntity(lightGreenSycamoreTree3)
lightGreenSycamoreTree3.setParent(_scene)
lightGreenSycamoreTree3.addComponentOrReplace(gltfShape5)
const transform10 = new Transform({
  position: new Vector3(35, 0, 22),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lightGreenSycamoreTree3.addComponentOrReplace(transform10)

const logRound = new Entity('logRound')
engine.addEntity(logRound)
logRound.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
logRound.addComponentOrReplace(transform11)
const gltfShape6 = new GLTFShape("451e0090-76a4-41e9-924b-cf30c148f3fc/Log_04/Log_04.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
logRound.addComponentOrReplace(gltfShape6)

const imperialGuardianLionStatue2 = new Entity('imperialGuardianLionStatue2')
engine.addEntity(imperialGuardianLionStatue2)
imperialGuardianLionStatue2.setParent(_scene)
imperialGuardianLionStatue2.addComponentOrReplace(gltfShape3)
const transform12 = new Transform({
  position: new Vector3(8, 0, 25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imperialGuardianLionStatue2.addComponentOrReplace(transform12)

const caribbeanShoreWithRocksPatch2 = new Entity('caribbeanShoreWithRocksPatch2')
engine.addEntity(caribbeanShoreWithRocksPatch2)
caribbeanShoreWithRocksPatch2.setParent(_scene)
caribbeanShoreWithRocksPatch2.addComponentOrReplace(gltfShape)
const transform13 = new Transform({
  position: new Vector3(30, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanShoreWithRocksPatch2.addComponentOrReplace(transform13)

const caribbeanShoreWithRocksPatch3 = new Entity('caribbeanShoreWithRocksPatch3')
engine.addEntity(caribbeanShoreWithRocksPatch3)
caribbeanShoreWithRocksPatch3.setParent(_scene)
caribbeanShoreWithRocksPatch3.addComponentOrReplace(gltfShape)
const transform14 = new Transform({
  position: new Vector3(23.5, 0, 8.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanShoreWithRocksPatch3.addComponentOrReplace(transform14)

const largeRoundBrickGrassBed = new Entity('largeRoundBrickGrassBed')
engine.addEntity(largeRoundBrickGrassBed)
largeRoundBrickGrassBed.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
largeRoundBrickGrassBed.addComponentOrReplace(transform15)
const gltfShape7 = new GLTFShape("8e71706b-3a3d-4255-b888-d86eb6318278/GrassPatchLarge_01/GrassPatchLarge_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
largeRoundBrickGrassBed.addComponentOrReplace(gltfShape7)

const largeRoundBrickGrassBed2 = new Entity('largeRoundBrickGrassBed2')
engine.addEntity(largeRoundBrickGrassBed2)
largeRoundBrickGrassBed2.setParent(_scene)
largeRoundBrickGrassBed2.addComponentOrReplace(gltfShape7)
const transform16 = new Transform({
  position: new Vector3(39.5, 0, 13),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
largeRoundBrickGrassBed2.addComponentOrReplace(transform16)

const largeRoundBrickGrassBed3 = new Entity('largeRoundBrickGrassBed3')
engine.addEntity(largeRoundBrickGrassBed3)
largeRoundBrickGrassBed3.setParent(_scene)
largeRoundBrickGrassBed3.addComponentOrReplace(gltfShape7)
const transform17 = new Transform({
  position: new Vector3(35, 0, 22),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
largeRoundBrickGrassBed3.addComponentOrReplace(transform17)

const dogStatue = new Entity('dogStatue')
engine.addEntity(dogStatue)
dogStatue.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(25, 0, 3.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
dogStatue.addComponentOrReplace(transform18)
const gltfShape8 = new GLTFShape("27946cd5-d0e7-4d3d-8542-ab33fc53ca30/PillarDog_01/PillarDog_01.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
dogStatue.addComponentOrReplace(gltfShape8)

const dogStatue2 = new Entity('dogStatue2')
engine.addEntity(dogStatue2)
dogStatue2.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(19, 0, 11.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
dogStatue2.addComponentOrReplace(transform19)
dogStatue2.addComponentOrReplace(gltfShape8)

const classicLampPost = new Entity('classicLampPost')
engine.addEntity(classicLampPost)
classicLampPost.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
classicLampPost.addComponentOrReplace(transform20)
const gltfShape9 = new GLTFShape("5fabab5a-62b8-4c39-8938-00d22395d057/LampPost_03/LampPost_03.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
classicLampPost.addComponentOrReplace(gltfShape9)

const classicLampPost2 = new Entity('classicLampPost2')
engine.addEntity(classicLampPost2)
classicLampPost2.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(15.5, 0, 10.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
classicLampPost2.addComponentOrReplace(transform21)
classicLampPost2.addComponentOrReplace(gltfShape9)

const umbrellaTable = new Entity('umbrellaTable')
engine.addEntity(umbrellaTable)
umbrellaTable.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(41.5, 0, 23),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
umbrellaTable.addComponentOrReplace(transform22)
const gltfShape10 = new GLTFShape("8bbdfe3a-8a61-4e93-9809-1d5e8d92f17a/TableBar_01/TableBar_01.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
umbrellaTable.addComponentOrReplace(gltfShape10)

const hardwoodRoundedBridge = new Entity('hardwoodRoundedBridge')
engine.addEntity(hardwoodRoundedBridge)
hardwoodRoundedBridge.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(24.5, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
hardwoodRoundedBridge.addComponentOrReplace(transform23)
const gltfShape11 = new GLTFShape("f9f8de37-8131-4e8a-b593-38cbac147001/Bridge_03/Bridge_03.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
hardwoodRoundedBridge.addComponentOrReplace(gltfShape11)

const caribbeanShoreWithRocksPatch4 = new Entity('caribbeanShoreWithRocksPatch4')
engine.addEntity(caribbeanShoreWithRocksPatch4)
caribbeanShoreWithRocksPatch4.setParent(_scene)
caribbeanShoreWithRocksPatch4.addComponentOrReplace(gltfShape)
const transform24 = new Transform({
  position: new Vector3(25.5, 0, 9.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanShoreWithRocksPatch4.addComponentOrReplace(transform24)

const temple = new Entity('temple')
engine.addEntity(temple)
temple.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(11, 0, 7),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
temple.addComponentOrReplace(transform25)
const gltfShape12 = new GLTFShape("d6a75fd6-7adc-431c-913f-6d15156936cf/ChineseHouse_01/ChineseHouse_01.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
temple.addComponentOrReplace(gltfShape12)

const caribbeanWater = new Entity('caribbeanWater')
engine.addEntity(caribbeanWater)
caribbeanWater.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(30, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWater.addComponentOrReplace(transform26)
const gltfShape13 = new GLTFShape("390b876e-4b3a-4e78-bd03-5be21b1ecc67/WaterPatchFull_01/WaterPatchFull_01.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
caribbeanWater.addComponentOrReplace(gltfShape13)

const bigStoneSlabTile = new Entity('bigStoneSlabTile')
engine.addEntity(bigStoneSlabTile)
bigStoneSlabTile.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bigStoneSlabTile.addComponentOrReplace(transform27)
const gltfShape14 = new GLTFShape("5ddd810b-9cc1-4451-bb65-2626e182d8b1/StoneSlabSmall_02/StoneSlabSmall_02.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
bigStoneSlabTile.addComponentOrReplace(gltfShape14)

const bigStonePath = new Entity('bigStonePath')
engine.addEntity(bigStonePath)
bigStonePath.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(34.5, 0, 5.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bigStonePath.addComponentOrReplace(transform28)
const gltfShape15 = new GLTFShape("363b9672-871b-4682-b15f-4f20f783789d/StonePath_02/StonePath_02.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
bigStonePath.addComponentOrReplace(gltfShape15)

const brownBicycle = new Entity('brownBicycle')
engine.addEntity(brownBicycle)
brownBicycle.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(24, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
brownBicycle.addComponentOrReplace(transform29)
const gltfShape16 = new GLTFShape("d7aa5ac8-ead7-4efb-8fe7-a3ec00322cc1/Bicycle_03/Bicycle_03.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
brownBicycle.addComponentOrReplace(gltfShape16)

const classicBench = new Entity('classicBench')
engine.addEntity(classicBench)
classicBench.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(24, 0, 20),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
classicBench.addComponentOrReplace(transform30)
const gltfShape17 = new GLTFShape("2cd78a5d-d01d-4d31-8940-c7fb8948e14e/Bench_01/Bench_01.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
classicBench.addComponentOrReplace(gltfShape17)

const classicBench2 = new Entity('classicBench2')
engine.addEntity(classicBench2)
classicBench2.setParent(_scene)
classicBench2.addComponentOrReplace(gltfShape17)
const transform31 = new Transform({
  position: new Vector3(32.5, 0, 13.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
classicBench2.addComponentOrReplace(transform31)

const grave = new Entity('grave')
engine.addEntity(grave)
grave.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(36.5, 0, 66.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave.addComponentOrReplace(transform32)
const gltfShape18 = new GLTFShape("b46a16b0-4acf-4086-b15d-636ac649ddea/HWN20_Grave_01.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
grave.addComponentOrReplace(gltfShape18)

const petTomb = new Entity('petTomb')
engine.addEntity(petTomb)
petTomb.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(41, 0, 69),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
petTomb.addComponentOrReplace(transform33)
const gltfShape19 = new GLTFShape("b26c083f-2734-4702-878d-46586940995f/HWN20_PetTomb_04.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
petTomb.addComponentOrReplace(gltfShape19)

const sidewalkTile = new Entity('sidewalkTile')
engine.addEntity(sidewalkTile)
sidewalkTile.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(30, 0, 33),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sidewalkTile.addComponentOrReplace(transform34)
const gltfShape20 = new GLTFShape("9e52d29e-d70c-4dc2-9cff-80cfc2771b58/FloorBlock_01/FloorBlock_01.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
sidewalkTile.addComponentOrReplace(gltfShape20)

const sidewalkTile2 = new Entity('sidewalkTile2')
engine.addEntity(sidewalkTile2)
sidewalkTile2.setParent(_scene)
sidewalkTile2.addComponentOrReplace(gltfShape20)
const transform35 = new Transform({
  position: new Vector3(30, 0, 33),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sidewalkTile2.addComponentOrReplace(transform35)

const sidewalkTile3 = new Entity('sidewalkTile3')
engine.addEntity(sidewalkTile3)
sidewalkTile3.setParent(_scene)
sidewalkTile3.addComponentOrReplace(gltfShape20)
const transform36 = new Transform({
  position: new Vector3(32.5, 0, 33.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sidewalkTile3.addComponentOrReplace(transform36)

const sidewalkTile4 = new Entity('sidewalkTile4')
engine.addEntity(sidewalkTile4)
sidewalkTile4.setParent(_scene)
sidewalkTile4.addComponentOrReplace(gltfShape20)
const transform37 = new Transform({
  position: new Vector3(27, 0, 32.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
sidewalkTile4.addComponentOrReplace(transform37)

const grave2 = new Entity('grave2')
engine.addEntity(grave2)
grave2.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(41.5, 0, 55),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave2.addComponentOrReplace(transform38)
const gltfShape21 = new GLTFShape("f0f8f9a5-d286-4a90-a167-7fe270a8be76/HWN20_Grave_19.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
grave2.addComponentOrReplace(gltfShape21)

const grave3 = new Entity('grave3')
engine.addEntity(grave3)
grave3.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(43, 0, 57.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave3.addComponentOrReplace(transform39)
const gltfShape22 = new GLTFShape("adf613b6-1516-4543-9c78-458ddb3a4256/HWN20_Grave_16.glb")
gltfShape22.withCollisions = true
gltfShape22.isPointerBlocker = true
gltfShape22.visible = true
grave3.addComponentOrReplace(gltfShape22)

const grave4 = new Entity('grave4')
engine.addEntity(grave4)
grave4.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(44.5, 0, 58.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave4.addComponentOrReplace(transform40)
const gltfShape23 = new GLTFShape("8b0d5631-234f-4d29-abe4-89e6d7436a3d/HWN20_Grave_12.glb")
gltfShape23.withCollisions = true
gltfShape23.isPointerBlocker = true
gltfShape23.visible = true
grave4.addComponentOrReplace(gltfShape23)

const grave5 = new Entity('grave5')
engine.addEntity(grave5)
grave5.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(40.5, 0, 59),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave5.addComponentOrReplace(transform41)
grave5.addComponentOrReplace(gltfShape23)

const grave6 = new Entity('grave6')
engine.addEntity(grave6)
grave6.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(42.5, 0, 60.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave6.addComponentOrReplace(transform42)
const gltfShape24 = new GLTFShape("531682f7-8ab9-400e-a690-91b8be211871/HWN20_Grave_07.glb")
gltfShape24.withCollisions = true
gltfShape24.isPointerBlocker = true
gltfShape24.visible = true
grave6.addComponentOrReplace(gltfShape24)

const grave7 = new Entity('grave7')
engine.addEntity(grave7)
grave7.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(40, 0, 65.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave7.addComponentOrReplace(transform43)
grave7.addComponentOrReplace(gltfShape21)

const grave8 = new Entity('grave8')
engine.addEntity(grave8)
grave8.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(45, 0, 64),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave8.addComponentOrReplace(transform44)
const gltfShape25 = new GLTFShape("4c95744e-059e-4d9d-89a0-fee6a2d582cb/HWN20_Grave_17.glb")
gltfShape25.withCollisions = true
gltfShape25.isPointerBlocker = true
gltfShape25.visible = true
grave8.addComponentOrReplace(gltfShape25)

const grave9 = new Entity('grave9')
engine.addEntity(grave9)
grave9.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(39, 0, 62),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave9.addComponentOrReplace(transform45)
const gltfShape26 = new GLTFShape("b27c3724-3c19-4418-a6a9-a661d9bfe5b3/HWN20_Grave_13.glb")
gltfShape26.withCollisions = true
gltfShape26.isPointerBlocker = true
gltfShape26.visible = true
grave9.addComponentOrReplace(gltfShape26)

const grave10 = new Entity('grave10')
engine.addEntity(grave10)
grave10.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(33, 0, 71.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave10.addComponentOrReplace(transform46)
const gltfShape27 = new GLTFShape("40d8ffd9-4165-4acd-b740-fe19b5e3db83/HWN20_Grave_18.glb")
gltfShape27.withCollisions = true
gltfShape27.isPointerBlocker = true
gltfShape27.visible = true
grave10.addComponentOrReplace(gltfShape27)

const lamp = new Entity('lamp')
engine.addEntity(lamp)
lamp.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(41, 0, 53.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lamp.addComponentOrReplace(transform47)
const gltfShape28 = new GLTFShape("07cb3b2f-fdc6-4fee-a7dd-8c95f88cfb80/HWN20_Lamp_01.glb")
gltfShape28.withCollisions = true
gltfShape28.isPointerBlocker = true
gltfShape28.visible = true
lamp.addComponentOrReplace(gltfShape28)

const lamp2 = new Entity('lamp2')
engine.addEntity(lamp2)
lamp2.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
lamp2.addComponentOrReplace(transform48)
lamp2.addComponentOrReplace(gltfShape28)

const grave11 = new Entity('grave11')
engine.addEntity(grave11)
grave11.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(34.5, 0, 63),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave11.addComponentOrReplace(transform49)
const gltfShape29 = new GLTFShape("1bee45e5-df63-4254-802e-5f8a76ab6a8d/HWN20_Grave_27.glb")
gltfShape29.withCollisions = true
gltfShape29.isPointerBlocker = true
gltfShape29.visible = true
grave11.addComponentOrReplace(gltfShape29)

const grave12 = new Entity('grave12')
engine.addEntity(grave12)
grave12.setParent(_scene)
const transform50 = new Transform({
  position: new Vector3(35, 0, 68.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
grave12.addComponentOrReplace(transform50)
const gltfShape30 = new GLTFShape("9065256f-fbc7-485c-a902-470b3988f311/HWN20_Grave_20.glb")
gltfShape30.withCollisions = true
gltfShape30.isPointerBlocker = true
gltfShape30.visible = true
grave12.addComponentOrReplace(gltfShape30)

const column = new Entity('column')
engine.addEntity(column)
column.setParent(_scene)
const transform51 = new Transform({
  position: new Vector3(20.5, 0, 50),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
column.addComponentOrReplace(transform51)
const gltfShape31 = new GLTFShape("2bb2e50a-96a1-42e1-82b2-f527bc9a89b3/HWN20_Column_04.glb")
gltfShape31.withCollisions = true
gltfShape31.isPointerBlocker = true
gltfShape31.visible = true
column.addComponentOrReplace(gltfShape31)

const rockTile = new Entity('rockTile')
engine.addEntity(rockTile)
rockTile.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile.addComponentOrReplace(transform52)
const gltfShape32 = new GLTFShape("5df296c5-f070-44dc-9ba2-8cafe7852037/FloorBlock_04/FloorBlock_04.glb")
gltfShape32.withCollisions = true
gltfShape32.isPointerBlocker = true
gltfShape32.visible = true
rockTile.addComponentOrReplace(gltfShape32)

const rockTile2 = new Entity('rockTile2')
engine.addEntity(rockTile2)
rockTile2.setParent(_scene)
rockTile2.addComponentOrReplace(gltfShape32)
const transform53 = new Transform({
  position: new Vector3(22.5, 0, 74),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile2.addComponentOrReplace(transform53)

const rockTile3 = new Entity('rockTile3')
engine.addEntity(rockTile3)
rockTile3.setParent(_scene)
rockTile3.addComponentOrReplace(gltfShape32)
const transform54 = new Transform({
  position: new Vector3(25, 0, 70.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile3.addComponentOrReplace(transform54)

const rockTile4 = new Entity('rockTile4')
engine.addEntity(rockTile4)
rockTile4.setParent(_scene)
rockTile4.addComponentOrReplace(gltfShape32)
const transform55 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile4.addComponentOrReplace(transform55)

const rockTile5 = new Entity('rockTile5')
engine.addEntity(rockTile5)
rockTile5.setParent(_scene)
rockTile5.addComponentOrReplace(gltfShape32)
const transform56 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile5.addComponentOrReplace(transform56)

const rockTile6 = new Entity('rockTile6')
engine.addEntity(rockTile6)
rockTile6.setParent(_scene)
rockTile6.addComponentOrReplace(gltfShape32)
const transform57 = new Transform({
  position: new Vector3(22, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile6.addComponentOrReplace(transform57)

const rockTile7 = new Entity('rockTile7')
engine.addEntity(rockTile7)
rockTile7.setParent(_scene)
rockTile7.addComponentOrReplace(gltfShape32)
const transform58 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile7.addComponentOrReplace(transform58)

const rockTile8 = new Entity('rockTile8')
engine.addEntity(rockTile8)
rockTile8.setParent(_scene)
rockTile8.addComponentOrReplace(gltfShape32)
const transform59 = new Transform({
  position: new Vector3(26, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile8.addComponentOrReplace(transform59)

const rockTile9 = new Entity('rockTile9')
engine.addEntity(rockTile9)
rockTile9.setParent(_scene)
rockTile9.addComponentOrReplace(gltfShape32)
const transform60 = new Transform({
  position: new Vector3(24.5, 0, 74),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile9.addComponentOrReplace(transform60)

const rockTile10 = new Entity('rockTile10')
engine.addEntity(rockTile10)
rockTile10.setParent(_scene)
const transform61 = new Transform({
  position: new Vector3(26, 0, 74),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile10.addComponentOrReplace(transform61)
rockTile10.addComponentOrReplace(gltfShape32)

const rockTile11 = new Entity('rockTile11')
engine.addEntity(rockTile11)
rockTile11.setParent(_scene)
const transform62 = new Transform({
  position: new Vector3(28, 0, 74.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile11.addComponentOrReplace(transform62)
rockTile11.addComponentOrReplace(gltfShape32)

const rockTile12 = new Entity('rockTile12')
engine.addEntity(rockTile12)
rockTile12.setParent(_scene)
const transform63 = new Transform({
  position: new Vector3(29.5, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile12.addComponentOrReplace(transform63)
rockTile12.addComponentOrReplace(gltfShape32)

const rockTile13 = new Entity('rockTile13')
engine.addEntity(rockTile13)
rockTile13.setParent(_scene)
const transform64 = new Transform({
  position: new Vector3(27.5, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile13.addComponentOrReplace(transform64)
rockTile13.addComponentOrReplace(gltfShape32)

const rockTile14 = new Entity('rockTile14')
engine.addEntity(rockTile14)
rockTile14.setParent(_scene)
const transform65 = new Transform({
  position: new Vector3(30.5, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile14.addComponentOrReplace(transform65)
rockTile14.addComponentOrReplace(gltfShape32)

const rockTile15 = new Entity('rockTile15')
engine.addEntity(rockTile15)
rockTile15.setParent(_scene)
const transform66 = new Transform({
  position: new Vector3(28, 0, 72.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile15.addComponentOrReplace(transform66)
rockTile15.addComponentOrReplace(gltfShape32)

const rockTile16 = new Entity('rockTile16')
engine.addEntity(rockTile16)
rockTile16.setParent(_scene)
const transform67 = new Transform({
  position: new Vector3(26, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile16.addComponentOrReplace(transform67)
rockTile16.addComponentOrReplace(gltfShape32)

const rockTile17 = new Entity('rockTile17')
engine.addEntity(rockTile17)
rockTile17.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(30, 0, 74),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile17.addComponentOrReplace(transform68)
rockTile17.addComponentOrReplace(gltfShape32)

const rockTile18 = new Entity('rockTile18')
engine.addEntity(rockTile18)
rockTile18.setParent(_scene)
const transform69 = new Transform({
  position: new Vector3(28, 0, 70.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile18.addComponentOrReplace(transform69)
rockTile18.addComponentOrReplace(gltfShape32)

const rockTile19 = new Entity('rockTile19')
engine.addEntity(rockTile19)
rockTile19.setParent(_scene)
const transform70 = new Transform({
  position: new Vector3(26.5, 0, 70),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile19.addComponentOrReplace(transform70)
rockTile19.addComponentOrReplace(gltfShape32)

const rockTile20 = new Entity('rockTile20')
engine.addEntity(rockTile20)
rockTile20.setParent(_scene)
const transform71 = new Transform({
  position: new Vector3(26.5, 0, 60.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile20.addComponentOrReplace(transform71)
rockTile20.addComponentOrReplace(gltfShape32)

const rockTile21 = new Entity('rockTile21')
engine.addEntity(rockTile21)
rockTile21.setParent(_scene)
const transform72 = new Transform({
  position: new Vector3(26.5, 0, 69),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile21.addComponentOrReplace(transform72)
rockTile21.addComponentOrReplace(gltfShape32)

const rockTile22 = new Entity('rockTile22')
engine.addEntity(rockTile22)
rockTile22.setParent(_scene)
const transform73 = new Transform({
  position: new Vector3(26.5, 0, 65),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile22.addComponentOrReplace(transform73)
rockTile22.addComponentOrReplace(gltfShape32)

const rockTile23 = new Entity('rockTile23')
engine.addEntity(rockTile23)
rockTile23.setParent(_scene)
rockTile23.addComponentOrReplace(gltfShape32)
const transform74 = new Transform({
  position: new Vector3(28.5, 0, 62.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile23.addComponentOrReplace(transform74)

const rockTile24 = new Entity('rockTile24')
engine.addEntity(rockTile24)
rockTile24.setParent(_scene)
rockTile24.addComponentOrReplace(gltfShape32)
const transform75 = new Transform({
  position: new Vector3(26.5, 0, 65),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile24.addComponentOrReplace(transform75)

const rockTile25 = new Entity('rockTile25')
engine.addEntity(rockTile25)
rockTile25.setParent(_scene)
rockTile25.addComponentOrReplace(gltfShape32)
const transform76 = new Transform({
  position: new Vector3(26.5, 0, 65),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile25.addComponentOrReplace(transform76)

const rockTile26 = new Entity('rockTile26')
engine.addEntity(rockTile26)
rockTile26.setParent(_scene)
rockTile26.addComponentOrReplace(gltfShape32)
const transform77 = new Transform({
  position: new Vector3(26.5, 0, 66.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile26.addComponentOrReplace(transform77)

const rockTile27 = new Entity('rockTile27')
engine.addEntity(rockTile27)
rockTile27.setParent(_scene)
rockTile27.addComponentOrReplace(gltfShape32)
const transform78 = new Transform({
  position: new Vector3(26.5, 0, 62.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
rockTile27.addComponentOrReplace(transform78)

const ironFenceDoor = new Entity('ironFenceDoor')
engine.addEntity(ironFenceDoor)
ironFenceDoor.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(29, 0, 67),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ironFenceDoor.addComponentOrReplace(transform79)
const gltfShape33 = new GLTFShape("3c1b0a40-3225-49e0-b3ff-de947afe8306/FenceIronDoor_01/FenceIronDoor_01.glb")
gltfShape33.withCollisions = true
gltfShape33.isPointerBlocker = true
gltfShape33.visible = true
ironFenceDoor.addComponentOrReplace(gltfShape33)

const ironFenceDoor2 = new Entity('ironFenceDoor2')
engine.addEntity(ironFenceDoor2)
ironFenceDoor2.setParent(_scene)
ironFenceDoor2.addComponentOrReplace(gltfShape33)
const transform80 = new Transform({
  position: new Vector3(29.5, 0, 69),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ironFenceDoor2.addComponentOrReplace(transform80)

const deckMV = new Entity('deckMV')
engine.addEntity(deckMV)
deckMV.setParent(_scene)
const transform81 = new Transform({
  position: new Vector3(41.5, 0, 77.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
deckMV.addComponentOrReplace(transform81)
const gltfShape34 = new GLTFShape("60e3f5da-ec94-4c05-bf01-21b70331a2a2/Deck 7M v02.glb")
gltfShape34.withCollisions = true
gltfShape34.isPointerBlocker = true
gltfShape34.visible = true
deckMV.addComponentOrReplace(gltfShape34)

const houseMYellow = new Entity('houseMYellow')
engine.addEntity(houseMYellow)
houseMYellow.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(13, 0, 94.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
houseMYellow.addComponentOrReplace(transform82)
const gltfShape35 = new GLTFShape("cb18c198-3228-403d-ab68-9c9f5105ad82/House 6 M Yellow.glb")
gltfShape35.withCollisions = true
gltfShape35.isPointerBlocker = true
gltfShape35.visible = true
houseMYellow.addComponentOrReplace(gltfShape35)

const caribbeanWaterWithCornerRocks = new Entity('caribbeanWaterWithCornerRocks')
engine.addEntity(caribbeanWaterWithCornerRocks)
caribbeanWaterWithCornerRocks.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(17, 0, 53),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks.addComponentOrReplace(transform83)
const gltfShape36 = new GLTFShape("fc559a0b-41b9-4d53-b24c-1713ad9c161c/WaterPatchCornerInside_01/WaterPatchCornerInside_01.glb")
gltfShape36.withCollisions = true
gltfShape36.isPointerBlocker = true
gltfShape36.visible = true
caribbeanWaterWithCornerRocks.addComponentOrReplace(gltfShape36)

const caribbeanWaterWithCornerRocks2 = new Entity('caribbeanWaterWithCornerRocks2')
engine.addEntity(caribbeanWaterWithCornerRocks2)
caribbeanWaterWithCornerRocks2.setParent(_scene)
caribbeanWaterWithCornerRocks2.addComponentOrReplace(gltfShape36)
const transform84 = new Transform({
  position: new Vector3(9.5, 0, 54),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks2.addComponentOrReplace(transform84)

const caribbeanWaterWithCornerRocks3 = new Entity('caribbeanWaterWithCornerRocks3')
engine.addEntity(caribbeanWaterWithCornerRocks3)
caribbeanWaterWithCornerRocks3.setParent(_scene)
caribbeanWaterWithCornerRocks3.addComponentOrReplace(gltfShape36)
const transform85 = new Transform({
  position: new Vector3(18, 0, 45.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks3.addComponentOrReplace(transform85)

const caribbeanWaterWithCornerRocks4 = new Entity('caribbeanWaterWithCornerRocks4')
engine.addEntity(caribbeanWaterWithCornerRocks4)
caribbeanWaterWithCornerRocks4.setParent(_scene)
caribbeanWaterWithCornerRocks4.addComponentOrReplace(gltfShape36)
const transform86 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks4.addComponentOrReplace(transform86)

const smalStonePath = new Entity('smalStonePath')
engine.addEntity(smalStonePath)
smalStonePath.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(26, 0, 76.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
smalStonePath.addComponentOrReplace(transform87)
const gltfShape37 = new GLTFShape("a1efa701-cd29-4296-9a92-9aeb8ebdaaf7/StonePath_03/StonePath_03.glb")
gltfShape37.withCollisions = true
gltfShape37.isPointerBlocker = true
gltfShape37.visible = true
smalStonePath.addComponentOrReplace(gltfShape37)

const mediumStoneSlabTile = new Entity('mediumStoneSlabTile')
engine.addEntity(mediumStoneSlabTile)
mediumStoneSlabTile.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(26, 0, 76.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
mediumStoneSlabTile.addComponentOrReplace(transform88)
const gltfShape38 = new GLTFShape("15ebf945-a8c6-4f2e-993d-660b0e93441d/StoneSlabMedium_01/StoneSlabMedium_01.glb")
gltfShape38.withCollisions = true
gltfShape38.isPointerBlocker = true
gltfShape38.visible = true
mediumStoneSlabTile.addComponentOrReplace(gltfShape38)

const stonePath = new Entity('stonePath')
engine.addEntity(stonePath)
stonePath.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(26, 0, 76.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
stonePath.addComponentOrReplace(transform89)
const gltfShape39 = new GLTFShape("1aa57826-1afe-466c-ab11-afd5f0df702c/StonePath_01/StonePath_01.glb")
gltfShape39.withCollisions = true
gltfShape39.isPointerBlocker = true
gltfShape39.visible = true
stonePath.addComponentOrReplace(gltfShape39)

const caribbeanWaterWithCornerRocks5 = new Entity('caribbeanWaterWithCornerRocks5')
engine.addEntity(caribbeanWaterWithCornerRocks5)
caribbeanWaterWithCornerRocks5.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(25.5, 0, 45),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks5.addComponentOrReplace(transform90)
caribbeanWaterWithCornerRocks5.addComponentOrReplace(gltfShape36)

const caribbeanWaterWithCornerRocks6 = new Entity('caribbeanWaterWithCornerRocks6')
engine.addEntity(caribbeanWaterWithCornerRocks6)
caribbeanWaterWithCornerRocks6.setParent(_scene)
caribbeanWaterWithCornerRocks6.addComponentOrReplace(gltfShape36)
const transform91 = new Transform({
  position: new Vector3(27, 0, 34.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks6.addComponentOrReplace(transform91)

const caribbeanWaterWithCornerRocks7 = new Entity('caribbeanWaterWithCornerRocks7')
engine.addEntity(caribbeanWaterWithCornerRocks7)
caribbeanWaterWithCornerRocks7.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(10, 0, 46),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks7.addComponentOrReplace(transform92)
caribbeanWaterWithCornerRocks7.addComponentOrReplace(gltfShape36)

const theFountainOfSpirits = new Entity('theFountainOfSpirits')
engine.addEntity(theFountainOfSpirits)
theFountainOfSpirits.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(27.5, 0, 92),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
theFountainOfSpirits.addComponentOrReplace(transform93)
const gltfShape40 = new GLTFShape("fca5ed25-573f-4792-ac64-3d5a48933dec/Fountain_01/Fountain_01.glb")
gltfShape40.withCollisions = true
gltfShape40.isPointerBlocker = true
gltfShape40.visible = true
theFountainOfSpirits.addComponentOrReplace(gltfShape40)

const noIMAGE = new Entity('noIMAGE')
engine.addEntity(noIMAGE)
noIMAGE.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(12.5, 0, 59),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
noIMAGE.addComponentOrReplace(transform94)
const gltfShape41 = new GLTFShape("ea601b6c-3d21-4c34-b4cb-620c7022d3a2/GreenHouse_02/GreenHouse_02.glb")
gltfShape41.withCollisions = true
gltfShape41.isPointerBlocker = true
gltfShape41.visible = true
noIMAGE.addComponentOrReplace(gltfShape41)

const enclosedHallJunction = new Entity('enclosedHallJunction')
engine.addEntity(enclosedHallJunction)
enclosedHallJunction.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(28.5, 0, 115.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
enclosedHallJunction.addComponentOrReplace(transform95)
const gltfShape42 = new GLTFShape("506287b3-c449-4e13-8c1f-705ffd14cb66/Hallway_Big_Module_01/Hallway_Big_Module_01.glb")
gltfShape42.withCollisions = true
gltfShape42.isPointerBlocker = true
gltfShape42.visible = true
enclosedHallJunction.addComponentOrReplace(gltfShape42)

const turretArray = new Entity('turretArray')
engine.addEntity(turretArray)
turretArray.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(20, 0, 64.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
turretArray.addComponentOrReplace(transform96)
const gltfShape43 = new GLTFShape("c9a51621-9fdb-44fd-ae7b-2cb0f773072c/Turret_03/Turret_03.glb")
gltfShape43.withCollisions = true
gltfShape43.isPointerBlocker = true
gltfShape43.visible = true
turretArray.addComponentOrReplace(gltfShape43)

const caribbeanWaterWithCornerRocks8 = new Entity('caribbeanWaterWithCornerRocks8')
engine.addEntity(caribbeanWaterWithCornerRocks8)
caribbeanWaterWithCornerRocks8.setParent(_scene)
caribbeanWaterWithCornerRocks8.addComponentOrReplace(gltfShape36)
const transform97 = new Transform({
  position: new Vector3(34.5, 0, 33),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks8.addComponentOrReplace(transform97)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape44 = new GLTFShape("4902949a-b64a-4225-9cb6-1d8c7e4cf08f/Grass Stones.glb")
gltfShape44.withCollisions = true
gltfShape44.isPointerBlocker = true
gltfShape44.visible = true
entity.addComponentOrReplace(gltfShape44)
const transform98 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform98)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape44)
const transform99 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform99)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape44)
const transform100 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform100)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape44)
const transform101 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform101)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape44)
const transform102 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform102)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape44)
const transform103 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform103)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape44)
const transform104 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform104)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape44)
const transform105 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform105)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape44)
const transform106 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform106)

const entity10 = new Entity('entity10')
engine.addEntity(entity10)
entity10.setParent(_scene)
entity10.addComponentOrReplace(gltfShape44)
const transform107 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity10.addComponentOrReplace(transform107)

const entity11 = new Entity('entity11')
engine.addEntity(entity11)
entity11.setParent(_scene)
entity11.addComponentOrReplace(gltfShape44)
const transform108 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity11.addComponentOrReplace(transform108)

const entity12 = new Entity('entity12')
engine.addEntity(entity12)
entity12.setParent(_scene)
entity12.addComponentOrReplace(gltfShape44)
const transform109 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity12.addComponentOrReplace(transform109)

const entity13 = new Entity('entity13')
engine.addEntity(entity13)
entity13.setParent(_scene)
entity13.addComponentOrReplace(gltfShape44)
const transform110 = new Transform({
  position: new Vector3(8, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity13.addComponentOrReplace(transform110)

const entity14 = new Entity('entity14')
engine.addEntity(entity14)
entity14.setParent(_scene)
entity14.addComponentOrReplace(gltfShape44)
const transform111 = new Transform({
  position: new Vector3(24, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity14.addComponentOrReplace(transform111)

const entity15 = new Entity('entity15')
engine.addEntity(entity15)
entity15.setParent(_scene)
entity15.addComponentOrReplace(gltfShape44)
const transform112 = new Transform({
  position: new Vector3(40, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity15.addComponentOrReplace(transform112)

const entity16 = new Entity('entity16')
engine.addEntity(entity16)
entity16.setParent(_scene)
entity16.addComponentOrReplace(gltfShape44)
const transform113 = new Transform({
  position: new Vector3(8, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity16.addComponentOrReplace(transform113)

const entity17 = new Entity('entity17')
engine.addEntity(entity17)
entity17.setParent(_scene)
entity17.addComponentOrReplace(gltfShape44)
const transform114 = new Transform({
  position: new Vector3(24, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity17.addComponentOrReplace(transform114)

const entity18 = new Entity('entity18')
engine.addEntity(entity18)
entity18.setParent(_scene)
entity18.addComponentOrReplace(gltfShape44)
const transform115 = new Transform({
  position: new Vector3(40, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity18.addComponentOrReplace(transform115)

const entity19 = new Entity('entity19')
engine.addEntity(entity19)
entity19.setParent(_scene)
entity19.addComponentOrReplace(gltfShape44)
const transform116 = new Transform({
  position: new Vector3(8, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity19.addComponentOrReplace(transform116)

const entity20 = new Entity('entity20')
engine.addEntity(entity20)
entity20.setParent(_scene)
entity20.addComponentOrReplace(gltfShape44)
const transform117 = new Transform({
  position: new Vector3(24, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity20.addComponentOrReplace(transform117)

const entity21 = new Entity('entity21')
engine.addEntity(entity21)
entity21.setParent(_scene)
entity21.addComponentOrReplace(gltfShape44)
const transform118 = new Transform({
  position: new Vector3(40, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity21.addComponentOrReplace(transform118)

const entity22 = new Entity('entity22')
engine.addEntity(entity22)
entity22.setParent(_scene)
entity22.addComponentOrReplace(gltfShape44)
const transform119 = new Transform({
  position: new Vector3(8, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity22.addComponentOrReplace(transform119)

const entity23 = new Entity('entity23')
engine.addEntity(entity23)
entity23.setParent(_scene)
entity23.addComponentOrReplace(gltfShape44)
const transform120 = new Transform({
  position: new Vector3(24, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity23.addComponentOrReplace(transform120)

const entity24 = new Entity('entity24')
engine.addEntity(entity24)
entity24.setParent(_scene)
entity24.addComponentOrReplace(gltfShape44)
const transform121 = new Transform({
  position: new Vector3(40, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity24.addComponentOrReplace(transform121)

const entity25 = new Entity('entity25')
engine.addEntity(entity25)
entity25.setParent(_scene)
entity25.addComponentOrReplace(gltfShape44)
const transform122 = new Transform({
  position: new Vector3(8, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity25.addComponentOrReplace(transform122)

const entity26 = new Entity('entity26')
engine.addEntity(entity26)
entity26.setParent(_scene)
entity26.addComponentOrReplace(gltfShape44)
const transform123 = new Transform({
  position: new Vector3(24, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity26.addComponentOrReplace(transform123)

const entity27 = new Entity('entity27')
engine.addEntity(entity27)
entity27.setParent(_scene)
entity27.addComponentOrReplace(gltfShape44)
const transform124 = new Transform({
  position: new Vector3(40, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity27.addComponentOrReplace(transform124)

const cartBigClosed = new Entity('cartBigClosed')
engine.addEntity(cartBigClosed)
cartBigClosed.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(4, 0, 70),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
cartBigClosed.addComponentOrReplace(transform125)
const gltfShape45 = new GLTFShape("23cee040-b0b9-48ca-bd49-43e2722f759d/Cart Big Closed.glb")
gltfShape45.withCollisions = true
gltfShape45.isPointerBlocker = true
gltfShape45.visible = true
cartBigClosed.addComponentOrReplace(gltfShape45)

const fruit = new Entity('fruit')
engine.addEntity(fruit)
fruit.setParent(_scene)
const transform126 = new Transform({
  position: new Vector3(24, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fruit.addComponentOrReplace(transform126)
const gltfShape46 = new GLTFShape("cce63be5-5cff-4843-bc9d-f3c910bebea3/Fruit 3.glb")
gltfShape46.withCollisions = true
gltfShape46.isPointerBlocker = true
gltfShape46.visible = true
fruit.addComponentOrReplace(gltfShape46)

const trainMachine = new Entity('trainMachine')
engine.addEntity(trainMachine)
trainMachine.setParent(_scene)
const transform127 = new Transform({
  position: new Vector3(42, 0, 93),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
trainMachine.addComponentOrReplace(transform127)
const gltfShape47 = new GLTFShape("33759e65-8fb6-41ce-ad95-ee5d4267ddd3/Train Machine.glb")
gltfShape47.withCollisions = true
gltfShape47.isPointerBlocker = true
gltfShape47.visible = true
trainMachine.addComponentOrReplace(gltfShape47)

const windmill = new Entity('windmill')
engine.addEntity(windmill)
windmill.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(13.5, 0, 76),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
windmill.addComponentOrReplace(transform128)
const gltfShape48 = new GLTFShape("562f7b91-5539-49da-b4fc-1b9f03413a3e/Windmill.glb")
gltfShape48.withCollisions = true
gltfShape48.isPointerBlocker = true
gltfShape48.visible = true
windmill.addComponentOrReplace(gltfShape48)

const beachRock = new Entity('beachRock')
engine.addEntity(beachRock)
beachRock.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(31, 0, 137.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
beachRock.addComponentOrReplace(transform129)
const gltfShape49 = new GLTFShape("41263fd0-8e9d-4a86-a849-fd285db9e450/RockBig_02/RockBig_02.glb")
gltfShape49.withCollisions = true
gltfShape49.isPointerBlocker = true
gltfShape49.visible = true
beachRock.addComponentOrReplace(gltfShape49)

const beachRock2 = new Entity('beachRock2')
engine.addEntity(beachRock2)
beachRock2.setParent(_scene)
beachRock2.addComponentOrReplace(gltfShape49)
const transform130 = new Transform({
  position: new Vector3(37, 0, 136),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
beachRock2.addComponentOrReplace(transform130)

const imperialPirateFlagship = new Entity('imperialPirateFlagship')
engine.addEntity(imperialPirateFlagship)
imperialPirateFlagship.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(21.5, 0, 137.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
imperialPirateFlagship.addComponentOrReplace(transform131)
const gltfShape50 = new GLTFShape("7a8474c6-326d-4c26-b785-c4c1e1e3d351/Ship_01/Ship_01.glb")
gltfShape50.withCollisions = true
gltfShape50.isPointerBlocker = true
gltfShape50.visible = true
imperialPirateFlagship.addComponentOrReplace(gltfShape50)

const caribbeanWaterWithCornerRocks9 = new Entity('caribbeanWaterWithCornerRocks9')
engine.addEntity(caribbeanWaterWithCornerRocks9)
caribbeanWaterWithCornerRocks9.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(31, 0, 143.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks9.addComponentOrReplace(transform132)
caribbeanWaterWithCornerRocks9.addComponentOrReplace(gltfShape36)

const caribbeanWaterWithCornerRocks10 = new Entity('caribbeanWaterWithCornerRocks10')
engine.addEntity(caribbeanWaterWithCornerRocks10)
caribbeanWaterWithCornerRocks10.setParent(_scene)
caribbeanWaterWithCornerRocks10.addComponentOrReplace(gltfShape36)
const transform133 = new Transform({
  position: new Vector3(30.5, 0, 138),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks10.addComponentOrReplace(transform133)

const caribbeanWaterWithCornerRocks11 = new Entity('caribbeanWaterWithCornerRocks11')
engine.addEntity(caribbeanWaterWithCornerRocks11)
caribbeanWaterWithCornerRocks11.setParent(_scene)
caribbeanWaterWithCornerRocks11.addComponentOrReplace(gltfShape36)
const transform134 = new Transform({
  position: new Vector3(36.5, 0, 143.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks11.addComponentOrReplace(transform134)

const caribbeanWaterWithCornerRocks12 = new Entity('caribbeanWaterWithCornerRocks12')
engine.addEntity(caribbeanWaterWithCornerRocks12)
caribbeanWaterWithCornerRocks12.setParent(_scene)
caribbeanWaterWithCornerRocks12.addComponentOrReplace(gltfShape36)
const transform135 = new Transform({
  position: new Vector3(22, 0, 141),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks12.addComponentOrReplace(transform135)

const caribbeanWaterWithCornerRocks13 = new Entity('caribbeanWaterWithCornerRocks13')
engine.addEntity(caribbeanWaterWithCornerRocks13)
caribbeanWaterWithCornerRocks13.setParent(_scene)
caribbeanWaterWithCornerRocks13.addComponentOrReplace(gltfShape36)
const transform136 = new Transform({
  position: new Vector3(42, 0, 144),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks13.addComponentOrReplace(transform136)

const caribbeanWaterWithCornerRocks14 = new Entity('caribbeanWaterWithCornerRocks14')
engine.addEntity(caribbeanWaterWithCornerRocks14)
caribbeanWaterWithCornerRocks14.setParent(_scene)
caribbeanWaterWithCornerRocks14.addComponentOrReplace(gltfShape36)
const transform137 = new Transform({
  position: new Vector3(47.5, 0, 143.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks14.addComponentOrReplace(transform137)

const caribbeanWaterWithCornerRocks15 = new Entity('caribbeanWaterWithCornerRocks15')
engine.addEntity(caribbeanWaterWithCornerRocks15)
caribbeanWaterWithCornerRocks15.setParent(_scene)
const transform138 = new Transform({
  position: new Vector3(43, 0, 142.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
caribbeanWaterWithCornerRocks15.addComponentOrReplace(transform138)
caribbeanWaterWithCornerRocks15.addComponentOrReplace(gltfShape36)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
script1.init(options)
script1.spawn(instagramButtonLink, {"url":"decentraland_art","bnw":false}, createChannel(channelId, instagramButtonLink, channelBus))
script1.spawn(instagramButtonLink2, {"url":"decentraland_art","bnw":false}, createChannel(channelId, instagramButtonLink2, channelBus))